package ir.rezanamroudi.familyfund

import retrofit2.http.*

interface ApiService {
    @FormUrlEncoded @POST("api.php?action=login")
    suspend fun login(@Field("phone") phone: String, @Field("password") password: String): ApiResponse<LoginData>

    @FormUrlEncoded @POST("api.php?action=register")
    suspend fun register(@Field("name") name: String, @Field("phone") phone: String, @Field("password") password: String): ApiResponse<LoginData>

    @GET("api.php?action=dashboard")
    suspend fun dashboard(@Header("Authorization") token: String): ApiResponse<Dashboard>

    @GET("api.php?action=members")
    suspend fun members(@Header("Authorization") token: String): ApiResponse<List<Member>>

    @GET("api.php?action=loan")
    suspend fun loan(@Header("Authorization") token: String): ApiResponse<Loan?>

    @GET("api.php?action=chat")
    suspend fun chat(@Header("Authorization") token: String): ApiResponse<List<ChatMessage>>

    @FormUrlEncoded @POST("api.php?action=chat_send")
    suspend fun sendChat(@Header("Authorization") token: String, @Field("message") message: String): ApiResponse<Any?>

    @GET("api.php?action=assets")
    suspend fun assets(@Header("Authorization") token: String): ApiResponse<Dashboard>
}

package ir.rezanamroudi.familyfund

object ApiConfig {
    // این آدرس را به آدرس پوشه server روی هاست خود تغییر دهید.
    const val BASE_URL = "https://YOUR-DOMAIN.COM/familyfund/server/"
}

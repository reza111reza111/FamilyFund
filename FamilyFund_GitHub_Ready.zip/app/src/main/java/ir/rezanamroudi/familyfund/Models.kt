package ir.rezanamroudi.familyfund

data class ApiResponse<T>(val ok: Boolean, val message: String? = null, val data: T? = null)
data class User(val id: Int, val name: String, val phone: String, val isAdmin: Int = 0)
data class LoginData(val token: String, val user: User)
data class Dashboard(val totalAssets: Long, val memberCount: Int, val myLoan: Long, val remainingInstallments: Int)
data class Member(val id: Int, val name: String)
data class Loan(val amount: Long, val installments: Int, val paidInstallments: Int, val remainingInstallments: Int, val monthlyPayment: Long)
data class ChatMessage(val id: Int, val userName: String, val message: String, val createdAt: String)

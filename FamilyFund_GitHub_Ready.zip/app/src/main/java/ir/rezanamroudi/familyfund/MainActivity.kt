package ir.rezanamroudi.familyfund

import android.app.*
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    private lateinit var api: ApiService
    private var token = ""
    private var currentUser: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        api = Retrofit.Builder().baseUrl(ApiConfig.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create()).build().create(ApiService::class.java)

        findViewById<Button>(R.id.loginBtn).setOnClickListener { login() }
        findViewById<Button>(R.id.registerBtn).setOnClickListener { registerDialog() }
        findViewById<Button>(R.id.assetsBtn).setOnClickListener { loadAssets() }
        findViewById<Button>(R.id.loanBtn).setOnClickListener { loadLoan() }
        findViewById<Button>(R.id.membersBtn).setOnClickListener { loadMembers() }
        findViewById<Button>(R.id.chatBtn).setOnClickListener { chatDialog() }
        findViewById<Button>(R.id.lotteryBtn).setOnClickListener { lottery() }
        findViewById<Button>(R.id.aboutBtn).setOnClickListener { about() }
        findViewById<Button>(R.id.logoutBtn).setOnClickListener { logout() }
    }

    private fun login() {
        val p = findViewById<EditText>(R.id.phone).text.toString().trim()
        val pass = findViewById<EditText>(R.id.password).text.toString()
        if (p.isBlank() || pass.isBlank()) return toast("شماره و رمز را وارد کنید")
        lifecycleScope.launch {
            try {
                val r = api.login(p, pass)
                if (r.ok && r.data != null) {
                    token = "Bearer ${r.data.token}"; currentUser = r.data.user
                    showHome()
                } else toast(r.message ?: "ورود ناموفق بود")
            } catch (e: Exception) { toast("خطا در ارتباط با سرور") }
        }
    }

    private fun registerDialog() {
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(35,10,35,0)
        val name = EditText(this); name.hint = "نام و نام خانوادگی"
        val phone = EditText(this); phone.hint = "شماره موبایل"
        val pass = EditText(this); pass.hint = "رمز عبور"; pass.inputType = 129
        box.addView(name); box.addView(phone); box.addView(pass)
        MaterialAlertDialogBuilder(this).setTitle("ثبت‌نام عضو جدید").setView(box)
            .setPositiveButton("ثبت‌نام") { _, _ ->
                lifecycleScope.launch {
                    try {
                        val r = api.register(name.text.toString(), phone.text.toString(), pass.text.toString())
                        if (r.ok && r.data != null) { token = "Bearer ${r.data.token}"; currentUser = r.data.user; showHome() }
                        else toast(r.message ?: "ثبت‌نام ناموفق بود")
                    } catch (e: Exception) { toast("خطا در ارتباط با سرور") }
                }
            }.setNegativeButton("انصراف", null).show()
    }

    private fun showHome() {
        findViewById<LinearLayout>(R.id.loginBox).visibility = LinearLayout.GONE
        findViewById<LinearLayout>(R.id.homeBox).visibility = LinearLayout.VISIBLE
        findViewById<TextView>(R.id.welcome).text = "سلام ${currentUser?.name ?: ""} 👋"
    }

    private fun loadAssets() = lifecycleScope.launch {
        try { val r = api.assets(token); r.data?.let { showInfo("دارایی صندوق", "موجودی صندوق: ${it.totalAssets} تومان\nتعداد اعضا: ${it.memberCount}") } }
        catch (e: Exception) { toast("خطا") }
    }

    private fun loadLoan() = lifecycleScope.launch {
        try {
            val l = api.loan(token).data
            if (l == null) showInfo("وام من", "در حال حاضر وامی برای شما ثبت نشده است.")
            else showInfo("وام من", "مبلغ وام: ${l.amount} تومان\nتعداد اقساط: ${l.installments}\nاقساط پرداخت‌شده: ${l.paidInstallments}\nاقساط باقی‌مانده: ${l.remainingInstallments}\nمبلغ هر قسط: ${l.monthlyPayment} تومان")
        } catch (e: Exception) { toast("خطا") }
    }

    private fun loadMembers() = lifecycleScope.launch {
        try {
            val m = api.members(token).data ?: emptyList()
            showInfo("اعضای صندوق", m.joinToString("\n") { "• ${it.name}" })
        } catch (e: Exception) { toast("خطا") }
    }

    private fun chatDialog() = lifecycleScope.launch {
        try {
            val list = api.chat(token).data ?: emptyList()
            val text = list.joinToString("\n\n") { "${it.userName}: ${it.message}" }
            val input = EditText(this@MainActivity); input.hint = "پیام جدید"
            val box = LinearLayout(this@MainActivity); box.orientation = LinearLayout.VERTICAL
            val history = TextView(this@MainActivity); history.text = if (text.isBlank()) "هنوز پیامی نیست." else text
            history.setPadding(20,10,20,10); box.addView(history); box.addView(input)
            MaterialAlertDialogBuilder(this@MainActivity).setTitle("💬 چت صندوق").setView(box)
                .setPositiveButton("ارسال") { _, _ ->
                    lifecycleScope.launch { api.sendChat(token, input.text.toString()); toast("پیام ارسال شد") }
                }.setNegativeButton("بستن", null).show()
        } catch (e: Exception) { toast("خطا") }
    }

    private fun lottery() = lifecycleScope.launch {
        try {
            val members = api.members(token).data ?: emptyList()
            if (members.isEmpty()) return@launch toast("عضوی وجود ندارد")
            val winner = members.random()
            MaterialAlertDialogBuilder(this@MainActivity).setTitle("🎲 نتیجه قرعه‌کشی")
                .setMessage("برنده:\n\n${winner.name} 🎉").setPositiveButton("باشه", null).show()
        } catch (e: Exception) { toast("خطا") }
    }

    private fun about() = showInfo("درباره برنامه",
        "صندوق وام فامیلی\n\nسازنده: رضا نمرودی ژاله\nشماره تماس: 09036791565")

    private fun logout() {
        token = ""; currentUser = null
        findViewById<LinearLayout>(R.id.homeBox).visibility = LinearLayout.GONE
        findViewById<LinearLayout>(R.id.loginBox).visibility = LinearLayout.VISIBLE
    }

    private fun showInfo(title: String, msg: String) =
        MaterialAlertDialogBuilder(this).setTitle(title).setMessage(msg).setPositiveButton("باشه", null).show()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

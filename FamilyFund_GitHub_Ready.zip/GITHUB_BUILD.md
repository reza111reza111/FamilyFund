# گرفتن APK از GitHub

1. یک Repository جدید در GitHub بسازید، مثلاً `FamilyFund`.
2. تمام فایل‌های این پوشه را داخل Repository قرار دهید و Commit کنید.
3. از منوی **Actions**، workflow با نام **Build Android APK** را انتخاب کنید.
4. روی **Run workflow** بزنید.
5. بعد از اتمام Build، وارد همان اجرای workflow شوید.
6. در قسمت **Artifacts** فایل `FamilyFund-debug-apk` را دانلود کنید.
7. APK داخل فایل ZIP قابل استخراج و نصب روی گوشی اندرویدی است.

## قبل از Build
در فایل:
`app/src/main/java/ir/rezanamroudi/familyfund/ApiConfig.kt`

مقدار `BASE_URL` را از `YOUR-DOMAIN.COM` به آدرس واقعی API خود تغییر دهید.

> این Workflow نسخه Debug را می‌سازد و برای تست مناسب است. برای انتشار در Google Play بهتر است بعداً signing و Release workflow اضافه شود.

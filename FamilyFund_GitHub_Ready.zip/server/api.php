<?php
require __DIR__.'/config.php';

$action = $_GET['action'] ?? '';

if ($action === 'login') {
    $phone=$_POST['phone']??''; $pass=$_POST['password']??'';
    $s=db()->prepare("SELECT * FROM users WHERE phone=? LIMIT 1"); $s->execute([$phone]); $u=$s->fetch();
    if (!$u || !password_verify($pass,$u['password'])) jsonOut(false,'شماره یا رمز اشتباه است');
    $token=bin2hex(random_bytes(32));
    db()->prepare("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 30 DAY))")->execute([$token,$u['id']]);
    jsonOut(true,'ورود موفق',['token'=>$token,'user'=>['id'=>(int)$u['id'],'name'=>$u['name'],'phone'=>$u['phone'],'isAdmin'=>(int)$u['is_admin']]]);
}

if ($action === 'register') {
    $name=trim($_POST['name']??''); $phone=trim($_POST['phone']??''); $pass=$_POST['password']??'';
    if (!$name || !$phone || strlen($pass)<4) jsonOut(false,'اطلاعات ثبت‌نام کامل نیست');
    try {
        db()->prepare("INSERT INTO users(name,phone,password) VALUES(?,?,?)")->execute([$name,$phone,password_hash($pass,PASSWORD_DEFAULT)]);
        $id=(int)db()->lastInsertId();
        $token=bin2hex(random_bytes(32));
        db()->prepare("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 30 DAY))")->execute([$token,$id]);
        jsonOut(true,'ثبت‌نام موفق',['token'=>$token,'user'=>['id'=>$id,'name'=>$name,'phone'=>$phone,'isAdmin'=>0]]);
    } catch(Throwable $e) { jsonOut(false,'این شماره قبلاً ثبت شده است'); }
}

$u=user(); if (!$u) jsonOut(false,'نیاز به ورود دارید');

if ($action === 'dashboard' || $action === 'assets') {
    $assets=(int)(db()->query("SELECT COALESCE(SUM(amount),0) x FROM fund_transactions WHERE type='in'")->fetch()['x'] -
                  db()->query("SELECT COALESCE(SUM(amount),0) x FROM fund_transactions WHERE type='out'")->fetch()['x']);
    $members=(int)db()->query("SELECT COUNT(*) c FROM users")->fetch()['c'];
    $loan=db()->prepare("SELECT * FROM loans WHERE user_id=? ORDER BY id DESC LIMIT 1"); $loan->execute([$u['id']]); $l=$loan->fetch();
    jsonOut(true,'',['totalAssets'=>$assets,'memberCount'=>$members,'myLoan'=>(int)($l['amount']??0),'remainingInstallments'=>(int)(($l['installments']??0)-($l['paid_installments']??0))]);
}

if ($action === 'members') {
    $rows=db()->query("SELECT id,name FROM users ORDER BY name")->fetchAll();
    jsonOut(true,'',array_map(fn($x)=>['id'=>(int)$x['id'],'name'=>$x['name']],$rows));
}

if ($action === 'loan') {
    $s=db()->prepare("SELECT amount,installments,paid_installments FROM loans WHERE user_id=? ORDER BY id DESC LIMIT 1"); $s->execute([$u['id']]); $l=$s->fetch();
    if (!$l) jsonOut(true,'',null);
    $monthly=(int)ceil($l['amount']/max(1,$l['installments']));
    jsonOut(true,'',['amount'=>(int)$l['amount'],'installments'=>(int)$l['installments'],'paidInstallments'=>(int)$l['paid_installments'],'remainingInstallments'=>(int)$l['installments']-(int)$l['paid_installments'],'monthlyPayment'=>$monthly]);
}

if ($action === 'chat') {
    $rows=db()->query("SELECT c.id,u.name userName,c.message,c.created_at createdAt FROM chat c JOIN users u ON u.id=c.user_id ORDER BY c.id DESC LIMIT 100")->fetchAll();
    jsonOut(true,'',array_reverse($rows));
}

if ($action === 'chat_send') {
    $msg=trim($_POST['message']??'');
    if (!$msg) jsonOut(false,'پیام خالی است');
    db()->prepare("INSERT INTO chat(user_id,message) VALUES(?,?)")->execute([$u['id'],$msg]);
    jsonOut(true,'پیام ارسال شد',null);
}

jsonOut(false,'دستور نامعتبر است');
